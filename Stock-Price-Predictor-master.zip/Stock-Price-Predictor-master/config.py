NEWS_API_KEY = 'Your News API Key'
